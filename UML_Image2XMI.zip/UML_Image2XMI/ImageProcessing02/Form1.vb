﻿Imports AForge
Imports AForge.Imaging
Imports AForge.Imaging.Filters
Imports AForge.Math.Geometry
Imports Accord.Imaging

Imports MODI

Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Windows.Forms
Imports System.Reflection
Imports System.Drawing.Drawing2D
Imports System.Xml
Imports System.IO
Imports System.Security

Public Class Form1

    Dim newImage101, newImage102 As Bitmap
    Dim miDoc As New MODI.Document

    Dim testColor As String


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        ''newImage = ZoomImage(newImage, 400)

        ''PictureBox1.Image = newImage

        ''PictureBox1.Update()

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)

        ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImage = filter3.Apply(newImage)

        ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As Filters.GaussianSharpen = New Filters.GaussianSharpen()
        ''newImage = filter.Apply(newImage)

        ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
        ''For s = 0 To 4
        ''newImage = filter1.Apply(newImage)
        ''Next


        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        For s = 0 To 5
            newImage = filter2.Apply(newImage)
        Next


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImg = filter.Apply(newImg)
        ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''Dim filter1 As Filters.Edges = New Filters.Edges()

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation
        newImage.UnlockBits(bitmapData)

        Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

        Dim g As Graphics = Graphics.FromImage(newImage)

        Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
        Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
        Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
        Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
        Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
        Dim whitePen = New Pen(Color.White, 4)

        Dim i As Integer = 0
        Dim n As Integer = blobs.Length
        While i < n


            Dim edgePoints As List(Of IntPoint) = blobCounter.GetBlobsEdgePoints(blobs(i))

            Dim center As DoublePoint
            Dim radius As Double

            'is Circle ??
            If shapeChecker.IsCircle(edgePoints, center, radius) Then
                ''g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
            Else

                Dim corners As List(Of IntPoint)

                ' is triangle or quadrilateral
                If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                    'get sub-type
                    Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                    Dim pen As Pen

                    ''If subType = PolygonSubType.Unknown Then
                    ''pen = If((corners.Count = 4), redPen, bluePen)
                    ''Else
                    ''  pen = If((corners.Count = 4), brownPen, greenPen)
                    ''End If
                    If (corners(0).X > 5 Or corners(0).Y > 5) And (corners(2).X < newImage.Size.Width - 5 Or corners(2).Y < newImage.Size.Height - 5) Then
                        If (subType = PolygonSubType.Square) Or (subType = PolygonSubType.Rectangle) Then
                            ''If corners.Count = 4 Then

                            ''**************************************************************************************************************************
                            ''**************************************************************************************************************************

                            testColor = newImage.GetPixel(corners(0).X, corners(0).Y).Name

                            ''**************************************************************************************************************************
                            ''**************************************************************************************************************************

                            pen = greenPen
                            ''pen = whitePen
                            g.DrawPolygon(pen, ToPointsArray(corners))


                            ''==============================================================================================
                            ''PictureBox1.Image = newImage

                            ''PictureBox1.Update()
                            ''==============================================================================================

                            Dim brush As New SolidBrush(Color.Green)
                            ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                            ''Dim brush As New SolidBrush(Color.Brown)
                            ''If ((corners(0).X > 10) And (corners(0).Y > 10)) Then
                            g.FillPolygon(brush, ToPointsArray(corners))

                            ''==============================================================================================
                            ''PictureBox1.Image = newImage

                            ''PictureBox1.Update()
                            ''==============================================================================================

                            ''ElseIf ((corners(2).X < newImage.Width - 10) And (corners(2).Y < newImage.Height - 10)) Then
                            ''g.FillPolygon(brush, ToPointsArray(corners))

                            ''==============================================================================================
                            ''PictureBox1.Image = newImage

                            ''PictureBox1.Update()
                            ''==============================================================================================

                            ''End If
                            ''End If


                            ''########################################################################################################################################
                            ''########################################################################################################################################
                            ''Else
                            ''  If subType = PolygonSubType.Unknown Then
                            ''''If corners.Count = 4 Then
                            ''pen = bluePen
                            ''g.DrawPolygon(pen, ToPointsArray(corners))

                            ''Dim brush As New SolidBrush(Color.Blue)
                            ''''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                            ''''Dim brush As New SolidBrush(Color.Brown)
                            ''g.FillPolygon(brush, ToPointsArray(corners))

                            ''==============================================================================================
                            ''PictureBox1.Image = newImage

                            ''PictureBox1.Update()
                            ''==============================================================================================

                            ''End If

                            ''########################################################################################################################################
                            ''########################################################################################################################################

                        End If
                    End If

                End If
            End If



            i += 1
        End While

        yellowPen.Dispose()
        redPen.Dispose()
        greenPen.Dispose()
        bluePen.Dispose()
        brownPen.Dispose()
        g.Dispose()

        'put new image to clipboard
        ''Clipboard.SetDataObject(newImage)
        'and to picture box
        PictureBox1.Image = newImage

        ''PictureBox1.Update()

        Remove()

    End Sub

    Private Function ToPointsArray(ByVal points As List(Of IntPoint)) As System.Drawing.Point()

        Dim array As System.Drawing.Point() = New System.Drawing.Point(points.Count - 1) {}
        Dim i As Integer = 0, n As Integer = points.Count

        While i < n
            array(i) = New System.Drawing.Point(points(i).X, points(i).Y)
            'If points(i).X = 0 Or points(i).Y = 0 Then Return array
            i += 1
        End While

        Return array

    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ' Sets the Dialog Title to Open File
        TextBox3.Text = ""
        OpenFileDialog1.Title = "Open File"

        ' Sets the File List box to Word documents and Excel documents
        OpenFileDialog1.Filter = "All files (*.*)|*.*|JPEG files (*.jpg)|*.jpg|GIF files (*.gif)|*.gif|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp"



        ' Set the default files type to Word Documents
        OpenFileDialog1.FilterIndex = 1

        ' Sets the flags - File must exist and Hide Read only
        ''OpenFileDialog1.Flags = cdlOFNFileMustExist + cdlOFNHideReadOnly

        ' Set dialog box so an error occurs if the dialogbox is cancelled
        ''OpenFileDialog1.CancelError = True

        ' Enables error handling to catch cancel error

        On Error Resume Next

        ' display the dialog box
        OpenFileDialog1.ShowDialog()
        ''If Err() Then
        ' This code runs if the dialog was cancelled
        ''MsgBox("Dialog Cancelled")
        ''Exit Sub
        ''End If
        ' Displays a message box.
        ''MsgBox("You selected " & OpenFileDialog1.FileName)

        PictureBox1.Image = System.Drawing.Image.FromFile(OpenFileDialog1.FileName)

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImage = filter.Apply(newImage)

        PictureBox1.Image = newImage


        newImage101 = New Bitmap(PictureBox1.Image)

        FlowLayoutPanel1.Visible = False
        PictureBox1.Visible = True

        ''If PictureBox1.Image.PixelFormat <> System.Drawing.Imaging.PixelFormat.Format16bppGrayScale Then


        ''End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImage = filter3.Apply(newImage)


        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        newImage = filter2.Apply(newImage)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation
        newImage.UnlockBits(bitmapData)

        Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

        Dim g As Graphics = Graphics.FromImage(newImage)

        Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
        Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
        Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
        Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
        Dim bluePen = New Pen(Color.Blue, 2)            ' triangle

        Dim i As Integer = 0, k = 0
        Dim n As Integer = blobs.Length
        While i < n


            Dim edgePoints As List(Of IntPoint) = blobCounter.GetBlobsEdgePoints(blobs(i))

            Dim center As DoublePoint
            Dim radius As Double

            'is Circle ??
            If shapeChecker.IsCircle(edgePoints, center, radius) Then
                g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
            Else

                Dim corners As List(Of IntPoint)

                ' is triangle or quadrilateral
                If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                    'get sub-type
                    Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                    ''Dim pen As Pen

                    If subType = PolygonSubType.Rectangle And (corners(0).X > 3) And (corners(0).Y > 3) Then
                        ''If subType = PolygonSubType.Unknown Then
                        ''pen = If((corners.Count = 4), redPen, bluePen)
                        ''Else
                        ''  pen = If((corners.Count = 4), brownPen, greenPen)
                        ''End If
                        k = k + 1
                        ''pen = Pens.Gold
                        ''g.DrawPolygon(pen, ToPointsArray(corners))

                        Dim brush As New SolidBrush(Color.Gold)
                        ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                        ''Dim brush As New SolidBrush(Color.Brown)
                        g.FillPolygon(brush, ToPointsArray(corners))
                        ''End If
                    End If
                End If
            End If



            i += 1
        End While

        yellowPen.Dispose()
        redPen.Dispose()
        greenPen.Dispose()
        bluePen.Dispose()
        brownPen.Dispose()
        g.Dispose()

        'put new image to clipboard
        Clipboard.SetDataObject(newImage)
        'and to picture box
        PictureBox1.Image = newImage

        PictureBox1.Update()
        MessageBox.Show(k, "Rectangle Counter", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        SaveFileDialog1.ShowDialog()
        newImage.Save(SaveFileDialog1.FileName)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click, Button4.Click
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)

        ''Dim filter4 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImg = filter4.Apply(newImg)

        ''Dim filter5 As Filters.Sharpen = New Filters.Sharpen()
        ''newImg = filter5.Apply(newImg)

        ''Dim filter6 As Filters.GaussianSharpen = New Filters.GaussianSharpen()
        ''For s = 0 To 10
        ''newImg = filter6.Apply(newImg)
        ''Next

        ''Dim filter As Filters.GaussianSharpen = New Filters.GaussianSharpen()
        ''newImage = filter.Apply(newImage)

        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)


        ''Dim filter3 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''newImg = filter3.Apply(newImg)

        Dim filter1 As AForge.Imaging.Filters.SobelEdgeDetector = New AForge.Imaging.Filters.SobelEdgeDetector()
        newImg = filter1.Apply(newImg)

        Dim filter2 As New Dilatation()
        newImg = filter2.Apply(newImg)

        ''Dim filter3 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''newImg = filter3.Apply(newImg)

        ''Dim filter2 As New Dilatation()
        ''newImg = filter2.Apply(newImg)

        ''Dim filter7 As Filters.Edges = New Filters.Edges()
        ''newImg = filter7.Apply(newImg)



        ''Dim filter3 As New Invert()
        ''newImg = filter3.Apply(newImg)



        PictureBox1.Image = newImg

        PictureBox1.Update()

    End Sub

    Public Function ZoomImage(ByVal img As System.Drawing.Image, ByVal ZoomValue As Int32) As System.Drawing.Image
        Dim width As Int32 = Convert.ToInt32(img.Width * ZoomValue) / 100
        Dim height As Int32 = Convert.ToInt32(img.Height * ZoomValue) / 100
        'Create a new image based on the zoom parameters we require
        Dim zoomImage1 As New System.Drawing.Bitmap(img, width, height)

        'Create a new graphics object based on the new image
        Dim converted As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(zoomImage1)

        'Clean up the image
        converted.InterpolationMode = InterpolationMode.HighQualityBicubic

        'Return the zoomed image
        Return zoomImage1
    End Function

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)
        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)
        Dim filter1 As AForge.Imaging.Filters.CannyEdgeDetector = New AForge.Imaging.Filters.CannyEdgeDetector()
        ''Dim filter1 As Filters.Edges = New Filters.Edges()
        newImg = filter1.Apply(newImg)

        PictureBox1.Image = newImg

        PictureBox1.Update()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)
        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)
        Dim filter1 As AForge.Imaging.Filters.DifferenceEdgeDetector = New AForge.Imaging.Filters.DifferenceEdgeDetector()
        newImg = filter1.Apply(newImg)


        PictureBox1.Image = newImg

        PictureBox1.Update()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        PictureBox1.Image = newImage101

        PictureBox1.Update()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        newImage101 = New Bitmap(PictureBox1.Image)
        FlowLayoutPanel1.Visible = False
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)
        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)

        PictureBox1.Image = newImg

        PictureBox1.Update()
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.Blue)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next

        PictureBox1.Image = newImage

        PictureBox1.Update()

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        TextBox1.Text = rects.Count.ToString + Environment.NewLine

        For Each rc As Rectangle In rects
            TextBox1.Text = TextBox1.Text + (String.Format("Position: (left{0}, top{1}), Size: {2} x {3}", rc.Left, rc.Top, rc.Width, rc.Height))
        Next


        ''TextBox1.Text = "Number of rectangle: " + rects.Length.ToString
        ''For i = 0 To rects.Length - 1
        ''TextBox1.Text = TextBox1.Text + Environment.NewLine + "Rectangle No. " + i.ToString + ": " + rects(i).Location.ToString
        ''Next



        ''MessageBox.Show(rects.Length, "Rectangle Counter", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = newImage.GetPixel(0, 0).Name Then newImage.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next

        PictureBox1.Image = newImage

        PictureBox1.Update()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        ''newImage = ZoomImage(newImage, 400)

        ''PictureBox1.Image = newImage

        ''PictureBox1.Update()

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)


        Dim filter1 As AForge.Imaging.Filters.Sharpen = New AForge.Imaging.Filters.Sharpen()
        newImage = filter1.Apply(newImage)

        ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImage = filter3.Apply(newImage)


        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        newImage = filter2.Apply(newImage)



        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation
        newImage.UnlockBits(bitmapData)

        Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

        Dim g As Graphics = Graphics.FromImage(newImage)

        Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
        Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
        Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
        Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
        Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
        Dim whitePen = New Pen(Color.White, 4)

        Dim i As Integer = 0
        Dim n As Integer = blobs.Length
        While i < n


            Dim edgePoints As List(Of IntPoint) = blobCounter.GetBlobsEdgePoints(blobs(i))

            Dim center As DoublePoint
            Dim radius As Double

            'is Circle ??
            If shapeChecker.IsCircle(edgePoints, center, radius) Then
                g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
            Else

                Dim corners As List(Of IntPoint)

                ' is triangle or quadrilateral
                If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                    'get sub-type
                    Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                    Dim pen As Pen

                    ''If subType = PolygonSubType.Unknown Then
                    ''pen = If((corners.Count = 4), redPen, bluePen)
                    ''Else
                    ''  pen = If((corners.Count = 4), brownPen, greenPen)
                    ''End If

                    If subType = PolygonSubType.Rectangle Then

                        pen = greenPen
                        ''pen = whitePen
                        g.DrawPolygon(pen, ToPointsArray(corners))

                        Dim brush As New SolidBrush(Color.Green)
                        ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                        ''Dim brush As New SolidBrush(Color.Brown)
                        If ((corners(0).X > 10) And (corners(0).Y > 10)) Then g.FillPolygon(brush, ToPointsArray(corners))
                        ''End If
                    Else
                        If subType = PolygonSubType.Unknown Then
                            pen = bluePen
                            g.DrawPolygon(pen, ToPointsArray(corners))

                            Dim brush As New SolidBrush(Color.Blue)
                            ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                            ''Dim brush As New SolidBrush(Color.Brown)
                            g.FillPolygon(brush, ToPointsArray(corners))
                        End If

                    End If

                End If
            End If



            i += 1
        End While

        yellowPen.Dispose()
        redPen.Dispose()
        greenPen.Dispose()
        bluePen.Dispose()
        brownPen.Dispose()
        g.Dispose()

        'put new image to clipboard
        Clipboard.SetDataObject(newImage)
        'and to picture box
        PictureBox1.Image = newImage

        PictureBox1.Update()
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim doc As New XmlDocument()
        'Create the document structure
        Dim pics As XmlNode = doc.CreateElement("pictures")
        Dim pic As XmlNode = doc.CreateElement("picture")
        pics.AppendChild(pic)
        doc.AppendChild(pics)

        'Read the bitmap.
        Dim data As String = Nothing
        ''Dim bmp As New Bitmap("c:\Images\Image.bmp")
        Dim bmp As Bitmap = New Bitmap(PictureBox1.Image)
        Dim mem As New MemoryStream()
        Try
            bmp.Save(mem, System.Drawing.Imaging.ImageFormat.Bmp)
            'Convert the bytes to a string.
            data = Convert.ToBase64String(mem.ToArray())
        Finally
            mem.Dispose()
        End Try
        'Save the data and the document.
        pic.InnerText = data
        doc.Save("c:\Bilal\Image.xml")
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        ' Sets the Dialog Title to Open File

        PictureBox1.Visible = False
        FlowLayoutPanel1.Visible = True

        OpenFileDialog1.Title = "Open File"

        ' Sets the File List box to Word documents and Excel documents
        OpenFileDialog1.Filter = "JPEG files (*.jpg)|*.jpg|GIF files (*.gif)|*.gif|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|All files (*.*)|*.*"

        OpenFileDialog1.Multiselect = True

        ' Set the default files type to Word Documents
        OpenFileDialog1.FilterIndex = 1

        ' Sets the flags - File must exist and Hide Read only
        ''OpenFileDialog1.Flags = cdlOFNFileMustExist + cdlOFNHideReadOnly

        ' Set dialog box so an error occurs if the dialogbox is cancelled
        ''OpenFileDialog1.CancelError = True

        ' Enables error handling to catch cancel error

        ''On Error Resume Next

        ' display the dialog box
        ''OpenFileDialog1.ShowDialog()
        ''If Err() Then
        ' This code runs if the dialog was cancelled
        ''MsgBox("Dialog Cancelled")
        ''Exit Sub
        ''End If
        ' Displays a message box.
        ''MsgBox("You selected " & OpenFileDialog1.FileName)
        Dim dr As DialogResult = OpenFileDialog1.ShowDialog()
        If (dr = System.Windows.Forms.DialogResult.OK) Then
            If FlowLayoutPanel1.Controls.Count <> 0 Then FlowLayoutPanel1.Controls.Clear()
            ' Read the files
            Dim file As String

            Dim j As Integer = 0

            For Each file In OpenFileDialog1.FileNames
                ' Create a PictureBox for each file, and add that file to the FlowLayoutPanel.
                Try
                    Dim pb As New PictureBox()

                    pb.Name = "pb_" & j.ToString

                    Dim loadedImage As System.Drawing.Image = System.Drawing.Image.FromFile(file)
                    ''pb.Height = loadedImage.Height
                    pb.Height = 150
                    ''pb.Width = loadedImage.Width
                    pb.Width = 100
                    pb.SizeMode = PictureBoxSizeMode.StretchImage
                    pb.Image = loadedImage
                    FlowLayoutPanel1.Controls.Add(pb)
                Catch SecEx As SecurityException
                    ' The user lacks appropriate permissions to read files, discover paths, etc.
                    MessageBox.Show("Security error. Please contact your administrator for details.\n\n" & _
                        "Error message: " & SecEx.Message & "\n\n" & _
                        "Details (send to Support):\n\n" & SecEx.StackTrace)
                Catch ex As Exception
                    ' Could not load the image - probably permissions-related.
                    MessageBox.Show(("Cannot display the image: " & file.Substring(file.LastIndexOf("\"c)) & _
                    ". You may not have permission to read the file, or " + "it may be corrupt." _
                    & ControlChars.Lf & ControlChars.Lf & "Reported error: " & ex.Message))
                End Try
                j = j + 1
            Next file
        End If
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click

        Dim c As Control()
        If FlowLayoutPanel1.Controls.Count > 0 Then
            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                c = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(c(0), PictureBox)
                Dim newImage As Bitmap = New Bitmap(pb.Image)

                ''newImage = ZoomImage(newImage, 400)

                ''PictureBox1.Image = newImage

                ''PictureBox1.Update()


                ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
                ''newImage = filter1.Apply(newImage)

                ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
                ''newImage = filter3.Apply(newImage)


                ''Dim filter2 As Filters.GaussianSharpen = New Filters.GaussianSharpen()
                ''newImage = filter2.Apply(newImage)

                Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
                For s = 0 To 5
                    newImage = filter2.Apply(newImage)
                Next

                Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
                Dim colorFilter As ColorFiltering = New ColorFiltering

                colorFilter.Red = New IntRange(0, 64)
                colorFilter.Green = New IntRange(0, 64)
                colorFilter.Blue = New IntRange(0, 64)
                colorFilter.FillOutsideRange = False

                colorFilter.ApplyInPlace(bitmapData)

                Dim blobCounter As BlobCounter = New BlobCounter()

                blobCounter.FilterBlobs = True
                blobCounter.MinHeight = 5
                blobCounter.MinWidth = 5

                blobCounter.ProcessImage(bitmapData)
                Dim blobs As Blob() = blobCounter.GetObjectsInformation
                newImage.UnlockBits(bitmapData)

                Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

                Dim g As Graphics = Graphics.FromImage(newImage)

                Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
                Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
                Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
                Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
                Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
                Dim whitePen = New Pen(Color.White, 4)

                Dim i As Integer = 0
                Dim n As Integer = blobs.Length
                While i < n


                    Dim edgePoints As List(Of IntPoint) = blobCounter.GetBlobsEdgePoints(blobs(i))

                    Dim center As DoublePoint
                    Dim radius As Double

                    'is Circle ??
                    If shapeChecker.IsCircle(edgePoints, center, radius) Then
                        ''g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
                    Else

                        Dim corners As List(Of IntPoint)

                        ' is triangle or quadrilateral
                        If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                            'get sub-type
                            Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                            Dim pen As Pen

                            ''If subType = PolygonSubType.Unknown Then
                            ''pen = If((corners.Count = 4), redPen, bluePen)
                            ''Else
                            ''  pen = If((corners.Count = 4), brownPen, greenPen)
                            ''End If

                            If (corners(0).X > 5 And corners(0).Y > 5) Or (corners(2).X < newImage.Size.Width - 5 And corners(2).Y < newImage.Size.Height - 5) Then
                                If (subType = PolygonSubType.Square) Or (subType = PolygonSubType.Rectangle) Then
                                    ''If corners.Count = 4 Then

                                    pen = greenPen
                                    ''pen = whitePen
                                    g.DrawPolygon(pen, ToPointsArray(corners))


                                    ''==============================================================================================
                                    ''PictureBox1.Image = newImage

                                    ''PictureBox1.Update()
                                    ''==============================================================================================

                                    Dim brush As New SolidBrush(Color.Green)
                                    ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                                    ''Dim brush As New SolidBrush(Color.Brown)
                                    ''If ((corners(0).X > 10) And (corners(0).Y > 10)) Then
                                    g.FillPolygon(brush, ToPointsArray(corners))

                                    ''==============================================================================================
                                    ''PictureBox1.Image = newImage

                                    ''PictureBox1.Update()
                                    ''==============================================================================================

                                    ''ElseIf ((corners(2).X < newImage.Width - 10) And (corners(2).Y < newImage.Height - 10)) Then
                                    ''g.FillPolygon(brush, ToPointsArray(corners))

                                    ''==============================================================================================
                                    ''PictureBox1.Image = newImage

                                    ''PictureBox1.Update()
                                    ''==============================================================================================

                                    ''End If
                                    ''End If


                                    ''####################################################################################################################################
                                    ''####################################################################################################################################

                                    ''Else
                                    ''  If subType = PolygonSubType.Unknown Then
                                    ''''If corners.Count = 4 Then
                                    ''pen = bluePen
                                    ''g.DrawPolygon(pen, ToPointsArray(corners))

                                    ''Dim brush As New SolidBrush(Color.Blue)
                                    ''''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                                    ''''Dim brush As New SolidBrush(Color.Brown)
                                    ''g.FillPolygon(brush, ToPointsArray(corners))

                                    ''''==============================================================================================
                                    ''''PictureBox1.Image = newImage

                                    ''''PictureBox1.Update()
                                    ''''==============================================================================================

                                    ''End If

                                    ''####################################################################################################################################
                                    ''####################################################################################################################################


                                End If
                            End If

                        End If
                    End If



                    i += 1
                End While

                yellowPen.Dispose()
                redPen.Dispose()
                greenPen.Dispose()
                bluePen.Dispose()
                brownPen.Dispose()
                g.Dispose()

                'put new image to clipboard
                Clipboard.SetDataObject(newImage)
                'and to picture box



                ''PictureBox1.Image = newImage
                pb.Image = newImage
                ''PictureBox1.Update()
                pb.Update()

            Next

            Remove2()

            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                Dim b As Control() = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(b(0), PictureBox)
                Dim newImg As Bitmap = New Bitmap(pb.Image)
                Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
                newImg = filter.Apply(newImg)
                ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
                ''Dim filter1 As Filters.Edges = New Filters.Edges()
                Dim filter1 As AForge.Imaging.Filters.SobelEdgeDetector = New AForge.Imaging.Filters.SobelEdgeDetector()
                newImg = filter1.Apply(newImg)

                pb.Image = newImg

                pb.Update()
            Next
        End If

    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


        If FlowLayoutPanel1.Controls.Count > 0 Then
            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                Dim c As Control() = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(c(0), PictureBox)
                Dim newImage As Bitmap = New Bitmap(pb.Image)

                ''Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

                Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

                Dim colorFilter As ColorFiltering = New ColorFiltering

                colorFilter.Red = New IntRange(0, 64)
                colorFilter.Green = New IntRange(0, 64)
                colorFilter.Blue = New IntRange(0, 64)
                colorFilter.FillOutsideRange = False

                colorFilter.ApplyInPlace(bitmapData)

                Dim blobCounter As BlobCounter = New BlobCounter()

                blobCounter.FilterBlobs = True
                blobCounter.MinHeight = 5
                blobCounter.MinWidth = 5

                blobCounter.ProcessImage(bitmapData)
                Dim blobs As Blob() = blobCounter.GetObjectsInformation

                newImage.UnlockBits(bitmapData)

                For i = 0 To (newImage.Width - 1)
                    For j = 0 To (newImage.Height - 1)
                        If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.White)
                        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                        ''TextBox1.Text = newImage.GetPixel(i, j).Name
                        ''End If

                    Next
                Next

                For i = 0 To (newImage.Width - 1)
                    For j = 0 To (newImage.Height - 1)
                        If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.Blue)
                        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                        ''TextBox1.Text = newImage.GetPixel(i, j).Name
                        ''End If

                    Next
                Next

                ''PictureBox1.Image = newImage
                pb.Image = newImage
                ''PictureBox1.Update()
                pb.Update()
            Next
        End If
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        ' Sets the Dialog Title to Open File
        ''OpenFileDialog1.Title = "Open File"
        PictureBox1.Visible = False
        FlowLayoutPanel1.Visible = True
        If (FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If FlowLayoutPanel1.Controls.Count <> 0 Then FlowLayoutPanel1.Controls.Clear()

            Dim x As String = FolderBrowserDialog1.SelectedPath
            Dim di As New IO.DirectoryInfo(x)
            Dim diar1 As IO.FileInfo() = di.GetFiles()
            Dim fi As IO.FileInfo

            Dim j As Integer = 0

            For Each fi In diar1
                If fi.Extension = ".jpg" Or fi.Extension = ".gif" Or fi.Extension = ".bmp" Or fi.Extension = ".png" Or fi.Extension = ".tif" Then

                    ' Create a PictureBox for each file, and add that file to the FlowLayoutPanel.

                    Dim pb As New PictureBox()

                    pb.Name = "pb_" & j.ToString

                    Dim str As String = fi.Name.ToString

                    Dim loadedImage As System.Drawing.Image = System.Drawing.Image.FromFile((x & "\" & fi.Name.ToString).ToString)
                    Dim newImage1 As Bitmap = New Bitmap(loadedImage)

                    Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
                    newImage1 = filter.Apply(newImage1)

                    ''pb.Height = loadedImage.Height

                    pb.Height = 150
                    ''pb.Width = loadedImage.Width
                    pb.Width = 100
                    pb.SizeMode = PictureBoxSizeMode.StretchImage
                    pb.Image = newImage1

                    FlowLayoutPanel1.Controls.Add(pb)

                    j = j + 1

                End If
            Next

        End If
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If FlowLayoutPanel1.Controls.Count > 0 Then
            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                Dim c As Control() = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(c(0), PictureBox)
                Dim newImage As Bitmap = New Bitmap(pb.Image)

                ''Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

                Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

                Dim colorFilter As ColorFiltering = New ColorFiltering

                colorFilter.Red = New IntRange(0, 64)
                colorFilter.Green = New IntRange(0, 64)
                colorFilter.Blue = New IntRange(0, 64)
                colorFilter.FillOutsideRange = False

                colorFilter.ApplyInPlace(bitmapData)

                Dim blobCounter As BlobCounter = New BlobCounter()

                blobCounter.FilterBlobs = True
                blobCounter.MinHeight = 5
                blobCounter.MinWidth = 5

                blobCounter.ProcessImage(bitmapData)
                Dim blobs As Blob() = blobCounter.GetObjectsInformation

                newImage.UnlockBits(bitmapData)

                For i = 0 To (newImage.Width - 1)
                    For j = 0 To (newImage.Height - 1)
                        If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Yellow)
                        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                        ''TextBox1.Text = newImage.GetPixel(i, j).Name
                        ''End If

                    Next
                Next

                For i = 0 To (newImage.Width - 1)
                    For j = 0 To (newImage.Height - 1)
                        If newImage.GetPixel(i, j).Name <> "ffffff00" Then newImage.SetPixel(i, j, Color.Green)
                        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                        ''TextBox1.Text = newImage.GetPixel(i, j).Name
                        ''End If

                    Next
                Next

                ''PictureBox1.Image = newImage
                pb.Image = newImage
                ''PictureBox1.Update()
                pb.Update()
            Next
        End If
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If FlowLayoutPanel1.Controls.Count > 0 Then
            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                Dim c As Control() = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(c(0), PictureBox)
                Dim newImg As Bitmap = New Bitmap(pb.Image)
                Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
                newImg = filter.Apply(newImg)
                ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
                ''Dim filter1 As Filters.Edges = New Filters.Edges()
                Dim filter1 As AForge.Imaging.Filters.SobelEdgeDetector = New AForge.Imaging.Filters.SobelEdgeDetector()
                newImg = filter1.Apply(newImg)

                pb.Image = newImg

                pb.Update()
            Next
        End If
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name <> "ff000000" Then newImage.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If
                TextBox1.Text = newImage.GetPixel(i, j).Name
            Next
        Next

        PictureBox1.Image = newImage

        PictureBox1.Update()
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        ''newImage = ZoomImage(newImage, TextBox2.Text)

        PictureBox1.Image = newImage

        PictureBox1.Update()
    End Sub


    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim quadTransformer As New QuadrilateralTransformation()

        Dim filter1 As AForge.Imaging.Filters.Sharpen = New AForge.Imaging.Filters.Sharpen()
        newImage = filter1.Apply(newImage)

        ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImage = filter3.Apply(newImage)


        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        newImage = filter2.Apply(newImage)



        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation
        newImage.UnlockBits(bitmapData)

        Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

        Dim g As Graphics = Graphics.FromImage(newImage)

        Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
        Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
        Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
        Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
        Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
        Dim whitePen = New Pen(Color.White, 4)

        Dim extractor As BlobCounter = New BlobCounter()
        extractor.FilterBlobs = True
        extractor.MinHeight = 5
        extractor.MinWidth = 5

        extractor.ProcessImage(bitmapData)

        For Each blob As Blob In extractor.GetObjectsInformation()
            'Get Edge points of card
            Dim edgePoints As List(Of IntPoint) = extractor.GetBlobsEdgePoints(blob)
            'Find corners of card on source image from edge points
            Dim corners As List(Of IntPoint) = PointsCloud.FindQuadrilateralCorners(edgePoints)

            If corners.Count = 4 Then
                quadTransformer.SourceQuadrilateral = corners
                quadTransformer.AutomaticSizeCalculaton = True
                ''Dim cardImg As Bitmap = quadTransformer.Apply(newImage)
            End If
        Next
    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ff000000" Then newImage.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If
                TextBox1.Text = newImage.GetPixel(i, j).Name
            Next
        Next

        PictureBox1.Image = newImage

        PictureBox1.Update()
    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button35.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim str As String = ""

        ''AxMiDocView1.Document = miDoc
        ''AxMiDocView1.Refresh()


        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        TextBox1.Text = "Number of rectangle: " + rects.Length.ToString
        For Each rc As Rectangle In rects
            ''TextBox1.Text = TextBox1.Text + Environment.NewLine + "Rectangle No. " + i.ToString + ": " + rects(i).Location.ToString
            ''str = AxMiDocView1.RectangleToClient(rc).ToString
            Dim cropped As Bitmap = newImage101.Clone(rc, newImage101.PixelFormat)
            cropped.Save("cropped.Bmp", ImageFormat.Bmp)
            Try
                miDoc = New MODI.Document
                miDoc.Create("cropped.Bmp")
                Dim modiImage As MODI.Image = DirectCast(miDoc.Images(0), MODI.Image)

                modiImage.OCR(MODI.MiLANGUAGES.miLANG_ENGLISH, False, False) ''///////////////////////////////////////////////////////


                For Each WordItem As MODI.Word In modiImage.Layout.Words

                    If WordItem.Text <> "" Then
                        str += WordItem.Text + " "
                        If WordItem.Text = "string" Or WordItem.Text = "String" Or WordItem.Text = "int" Or WordItem.Text = "int" Or WordItem.Text = "boolean" Or WordItem.Text = "Boolean" Or WordItem.Text = "void" Or WordItem.Text = "Void" Or WordItem.Text = "Integer" Or WordItem.Text = "integer" Or WordItem.Text = "bool" Or WordItem.Text = "Bool" Then str += Environment.NewLine
                    End If
                Next
            Catch ex As Exception

                miDoc.Close(False)
            End Try


            str += Environment.NewLine + "==============" + Environment.NewLine
        Next
        TextBox3.Text += Environment.NewLine + str
        ''For Each rc As Rectangle In rects
        ''TextBox1.Text = TextBox1.Text + (String.Format("Position: (left{0}, top{1}), Size: {2} x {3}", rc.Left, rc.Top, rc.Width, rc.Height))
        ''Next
    End Sub

    Private Sub Remove()
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next

        ''For i = 0 To (newImage.Width - 1)
        ''For j = 0 To (newImage.Height - 1)
        ''If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.Blue)
        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
        ''TextBox1.Text = newImage.GetPixel(i, j).Name
        ''End If

        ''Next
        ''Next

        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImage = filter.Apply(newImage)
        ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''Dim filter1 As Filters.Edges = New Filters.Edges()
        Dim filter1 As AForge.Imaging.Filters.SobelEdgeDetector = New AForge.Imaging.Filters.SobelEdgeDetector()
        newImage = filter1.Apply(newImage)

        PictureBox1.Image = newImage

        PictureBox1.Update()

        CountRectangle()

    End Sub

    Private Sub CountRectangle()
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        TextBox1.Text = "Number Of Rectangle: " + rects.Count.ToString + Environment.NewLine

        For Each rc As Rectangle In rects
            TextBox1.Text = TextBox1.Text + (String.Format("Position: (left {0}, top {1}), Size: {2} x {3}", rc.Left, rc.Top, rc.Width, rc.Height)) + Environment.NewLine
        Next
    End Sub

    Private Sub Remove2()
        If FlowLayoutPanel1.Controls.Count > 0 Then
            For k = 0 To (FlowLayoutPanel1.Controls.Count - 1)

                Dim c As Control() = FlowLayoutPanel1.Controls.Find("pb_" & k.ToString, True)
                Dim assembly As Assembly = Me.GetType().Assembly

                Dim pb As PictureBox = DirectCast(c(0), PictureBox)
                Dim newImage As Bitmap = New Bitmap(pb.Image)

                ''Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

                Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

                Dim colorFilter As ColorFiltering = New ColorFiltering

                colorFilter.Red = New IntRange(0, 64)
                colorFilter.Green = New IntRange(0, 64)
                colorFilter.Blue = New IntRange(0, 64)
                colorFilter.FillOutsideRange = False

                colorFilter.ApplyInPlace(bitmapData)

                Dim blobCounter As BlobCounter = New BlobCounter()

                blobCounter.FilterBlobs = True
                blobCounter.MinHeight = 5
                blobCounter.MinWidth = 5

                blobCounter.ProcessImage(bitmapData)
                Dim blobs As Blob() = blobCounter.GetObjectsInformation

                newImage.UnlockBits(bitmapData)

                For i = 0 To (newImage.Width - 1)
                    For j = 0 To (newImage.Height - 1)
                        If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.White)
                        ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                        ''TextBox1.Text = newImage.GetPixel(i, j).Name
                        ''End If

                    Next
                Next

                ''For i = 0 To (newImage.Width - 1)
                ''For j = 0 To (newImage.Height - 1)
                ''If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.Blue)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

                ''Next
                ''Next

                ''PictureBox1.Image = newImage
                pb.Image = newImage
                ''PictureBox1.Update()
                pb.Update()
            Next
        End If


    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim str As String = ""

        ''AxMiDocView1.Document = miDoc
        ''AxMiDocView1.Refresh()


        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        TextBox1.Text = "Number of rectangle: " + rects.Length.ToString
        For Each rc As Rectangle In rects
            ''TextBox1.Text = TextBox1.Text + Environment.NewLine + "Rectangle No. " + i.ToString + ": " + rects(i).Location.ToString
            ''str = AxMiDocView1.RectangleToClient(rc).ToString
            Dim cropped As Bitmap = newImage101.Clone(rc, newImage101.PixelFormat)



            cropped.Save("cropped.Bmp", ImageFormat.Bmp)
            Try
                miDoc = New MODI.Document
                miDoc.Create("cropped.Bmp")
                AxMiDocView1.Document = miDoc
                AxMiDocView1.Refresh()



                Dim modiImage As MODI.Image = DirectCast(miDoc.Images(0), MODI.Image)

                modiImage.OCR(MODI.MiLANGUAGES.miLANG_ENGLISH, False, False) ''///////////////////////////////////////////////////////

                AxMiDocView1.Document = miDoc
                AxMiDocView1.Refresh()

                For Each WordItem As MODI.Word In modiImage.Layout.Words

                    If WordItem.Text <> "" Then
                        str += WordItem.Text + " "
                        If WordItem.Text = "string" Or WordItem.Text = "String" Or WordItem.Text = "int" Or WordItem.Text = "int" Or WordItem.Text = "boolean" Or WordItem.Text = "Boolean" Or WordItem.Text = "void" Or WordItem.Text = "Void" Or WordItem.Text = "Integer" Or WordItem.Text = "integer" Or WordItem.Text = "bool" Or WordItem.Text = "Bool" Then str += Environment.NewLine
                    End If
                Next
            Catch ex As Exception

                miDoc.Close(False)
            End Try


            str += Environment.NewLine + "==============" + Environment.NewLine
        Next
        TextBox3.Text += Environment.NewLine + str
        ''For Each rc As Rectangle In rects
        ''TextBox1.Text = TextBox1.Text + (String.Format("Position: (left{0}, top{1}), Size: {2} x {3}", rc.Left, rc.Top, rc.Width, rc.Height))
        ''Next
    End Sub

    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If AxMiDocView1.TextSelection IsNot Nothing Then

            AxMiDocView1.TextSelection.CopyToClipboard()
        End If
    End Sub

    Private Sub AxMiDocView1_FitmodeChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AxMiDocView1.FitmodeChanged

    End Sub

    Private Sub Button29_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim newImage1 As Bitmap = New Bitmap(newImage101)

        Dim filter1 As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImage = filter1.Apply(newImage)

        Dim filter As New Dilatation()
        Dim se As Short(,) = New Short(,) {
          {-1, 1, -1},
        {1, 1, 1},
        {-1, 1, -1}
        }
        ''Dim filter As New Dilatation(se)
        Dim filter2 As New Dilatation()
        newImage = filter2.Apply(newImage)
        PictureBox1.Image = newImage
        PictureBox1.Update()



        Dim lineTransform As HoughLineTransformation = New HoughLineTransformation()
        '' apply Hough line transofrm
        lineTransform.ProcessImage(newImage)
        Dim houghLineImage As Bitmap = lineTransform.ToBitmap()
        '' get lines using relative intensity
        Dim lines As HoughLine() = lineTransform.GetLinesByRelativeIntensity(0.5)

        Dim g As Graphics = Graphics.FromImage(newImage1)
        PictureBox1.Image = newImage1

        TextBox1.Text = "Number Of lines: " + lines.Count.ToString + Environment.NewLine
        For Each line As HoughLine In lines


            TextBox1.Text = TextBox1.Text + "+ line theta: " + line.Theta.ToString + "    line radios" + line.Radius.ToString + Environment.NewLine
            '' get line's radius and theta values
            Dim r As Integer = line.Radius
            Dim t As Double = line.Theta


            '' check if line is in lower part of the image
            If r < 0 Then
                t += 180
                r = -r
            End If

            '' convert degrees to radians
            t = (t / 180) * Math.PI

            '' get image centers (all coordinate are measured relative to center)

            Dim w2 As Integer = newImage.Width / 2
            Dim h2 As Integer = newImage.Height / 2

            Dim x0 As Double = 0
            Dim x1 As Double = 0
            Dim y0 As Double = 0
            Dim y1 As Double = 0

            If line.Theta = 90 Then

                '' none vertical line
                x0 = -w2 '' most left point
                x1 = w2  '' most right point

                '' calculate corresponding y values
                y0 = (-Math.Cos(t) * x0 + r) / Math.Sin(t)
                y1 = (-Math.Cos(t) * x1 + r) / Math.Sin(t)

            ElseIf line.Theta = 0 Then

                '' vertical line
                x0 = line.Radius
                x1 = line.Radius

                y0 = h2
                y1 = -h2

            End If

            Dim p1 As System.Drawing.Point = New System.Drawing.Point(CInt(x0) + w2, h2 - CInt(y0))
            Dim p2 As System.Drawing.Point = New System.Drawing.Point(CInt(x1) + w2, h2 - CInt(y1))

            g.DrawLine(Pens.Blue, p1, p2)

            ''PictureBox1.Image = newImage1
            ''PictureBox1.Update()

            ''System.Threading.Thread.Sleep(500)
        Next


        PictureBox1.Image = newImage1
        PictureBox1.Update()

    End Sub

    Private Sub Button30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button30.Click
        ' Load image and create everything you need for drawing

        TextBox3.Text = ""

        Dim image As New Bitmap(PictureBox1.Image)

        ''Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        ''For s = 0 To 5
        ''image = filter2.Apply(image)
        ''Next

        Dim graphics__1 As Graphics = Graphics.FromImage(image)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)

        ' Create corner detector and have it process the image
        Dim mcd As New MoravecCornersDetector()
        Dim corners As List(Of IntPoint) = mcd.ProcessImage(image)

        ' Visualization: Draw 3x3 boxes around the corners
        For Each corner As IntPoint In corners
            graphics__1.DrawRectangle(pen, corner.X - 1, corner.Y - 1, 3, 3)
            TextBox3.Text = TextBox3.Text + "+ corner X:" + corner.X.ToString + "    corner Y:" + corner.Y.ToString + Environment.NewLine
        Next

        ' Display
        PictureBox1.Image = image
    End Sub

    
    Private Sub Button31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button31.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim newImage1 As Bitmap = New Bitmap(newImage101)


        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        TextBox1.Text = "Number of rectangle: " + rects.Length.ToString
        For Each rc As Rectangle In rects
            ''TextBox1.Text = TextBox1.Text + Environment.NewLine + "Rectangle No. " + i.ToString + ": " + rects(i).Location.ToString
            ''str = AxMiDocView1.RectangleToClient(rc).ToString

            Dim g As Graphics = Graphics.FromImage(newImage1)
            Dim brush As SolidBrush = New SolidBrush(newImage1.GetPixel(newImage.Width - 1, newImage.Height - 1))
            ''Dim pen As Pen = New Pen(Color.AliceBlue)

            ' create filled rectangle
            g.FillRectangle(brush, rc.Location.X - 1, rc.Location.Y - 1, rc.Width + 1, rc.Height + 1)

        Next

        PictureBox1.Image = newImage1
        PictureBox1.Update()

        ''Remove3()
    End Sub

    Private Sub Remove3()
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation

        newImage.UnlockBits(bitmapData)
        PictureBox1.Image = newImage
        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                ''If newImage.GetPixel(i, j).Name = testColor Then newImage.SetPixel(i, j, Color.Blue)
                If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.Black)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next


        PictureBox1.Image = newImage

        PictureBox1.Update()
        ''System.Threading.Thread.Sleep(5000)

        

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)


        ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''Dim filter1 As Filters.Edges = New Filters.Edges()


        ''Dim filter1 As Filters.SobelEdgeDetector = New Filters.SobelEdgeDetector()
        ''newImage = filter1.Apply(newImage)

        ''Dim se As Short(,) = New Short(,) {
        ''  {-1, 1, -1},
        ''{-1, 1, -1},
        ''{-1, 1, -1}
        ''}

        ''Dim filter1 As New HitAndMiss(se, HitAndMiss.Modes.Thinning)
        ''newImage = filter1.Apply(newImage)

        ''PictureBox1.Image = newImage

        ''PictureBox1.Update()
    End Sub

    Private Sub Button32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button32.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)



        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name <> "ffffffff" Then newImage.SetPixel(i, j, Color.Black)
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next

        Dim newImage2 As Bitmap = New Bitmap(newImage)
        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImage2 = filter.Apply(newImage2)
        ''Dim filter4 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''newImage2 = filter4.Apply(newImage2)
        ''######################################################################################
        ''######################################################################################

        Dim filter3 As Erosion = New Erosion()
        newImage2 = filter3.Apply(newImage2)
        newImage2 = filter3.Apply(newImage2)

        ''Dim filter4 As Opening = New Opening()
        ''newImage2 = filter4.Apply(newImage2)

        PictureBox1.Image = newImage2

        Dim newImage1 As Bitmap = New Bitmap(PictureBox1.Image)

        TextBox3.Text = ""


        Dim bitmapData1 As BitmapData = newImage1.LockBits(New Rectangle(0, 0, newImage1.Width, newImage1.Height), ImageLockMode.ReadWrite, newImage1.PixelFormat)

        Dim colorFilter1 As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter1 As BlobCounter = New BlobCounter()

        blobCounter1.FilterBlobs = True
        blobCounter1.MinHeight = 5
        blobCounter1.MinWidth = 5

        blobCounter1.ProcessImage(bitmapData)



        newImage1.UnlockBits(bitmapData1)



        For i = 0 To (newImage1.Width - 1)
            For j = 0 To (newImage1.Height - 1)
                If newImage1.GetPixel(i, j).Name <> "ff000000" Then newImage1.SetPixel(i, j, Color.White)
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            Next
        Next




        PictureBox1.Image = newImage1
        newImage102 = newImage1

        
        
    End Sub

    Private Sub Button33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button33.Click
        Dim newImage1 As Bitmap = New Bitmap(PictureBox1.Image)

        ''Dim str As String = ""

        ''Dim cropped As Bitmap
        ''AxMiDocView1.Document = miDoc
        ''AxMiDocView1.Refresh()


        Dim blobCounter As BlobCounter = New BlobCounter(newImage1)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        ''TextBox1.Text = "Number of rectangle: " + rects.Length.ToString
        For Each rc As Rectangle In rects
            ''TextBox1.Text = TextBox1.Text + Environment.NewLine + "Rectangle No. " + i.ToString + ": " + rects(i).Location.ToString
            ''str = AxMiDocView1.RectangleToClient(rc).ToString
            Dim newImage As Bitmap = newImage101.Clone(rc, newImage101.PixelFormat)
            Dim newImage2 As Bitmap = newImage101.Clone(rc, newImage101.PixelFormat)
            PictureBox2.Image = newImage2
            ''newImage.Save("cropped.Bmp", ImageFormat.Bmp)

            ''*******************************************
            ''*******************************************

            Dim assembly As Assembly = Me.GetType().Assembly

            Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
            For s = 0 To 5
                newImage = filter2.Apply(newImage)
            Next


            Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
            Dim colorFilter As ColorFiltering = New ColorFiltering

            colorFilter.Red = New IntRange(0, 64)
            colorFilter.Green = New IntRange(0, 64)
            colorFilter.Blue = New IntRange(0, 64)
            colorFilter.FillOutsideRange = False

            colorFilter.ApplyInPlace(bitmapData)

            Dim blobCounter1 As BlobCounter = New BlobCounter()

            blobCounter1.FilterBlobs = True
            blobCounter1.MinHeight = 5
            blobCounter1.MinWidth = 5

            blobCounter1.ProcessImage(bitmapData)
            Dim blobs As Blob() = blobCounter1.GetObjectsInformation
            newImage.UnlockBits(bitmapData)

            Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

            Dim g As Graphics = Graphics.FromImage(newImage)
            ''Dim k As Graphics = Graphics.FromImage(newImage2)

            Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
            Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
            Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
            Dim greenPen As Pen = New Pen(Color.Green, 1)   ' known triangle
            Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
            Dim whitePen = New Pen(Color.White, 4)

            ''Dim j As Integer = -1
            Dim i As Integer = 0
            Dim n As Integer = blobs.Length
            While i < n


                Dim edgePoints As List(Of IntPoint) = blobCounter1.GetBlobsEdgePoints(blobs(i))

                Dim center As DoublePoint
                Dim radius As Double

                'is Circle ??
                If shapeChecker.IsCircle(edgePoints, center, radius) Then
                    ''g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
                Else

                    Dim corners As List(Of IntPoint)

                    ' is triangle or quadrilateral
                    If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                        'get sub-type
                        Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                        Dim pen As Pen

                        ''If subType = PolygonSubType.Unknown Then
                        ''pen = If((corners.Count = 4), redPen, bluePen)
                        ''Else
                        ''  pen = If((corners.Count = 4), brownPen, greenPen)
                        ''End If
                        If (corners(0).X < 5 And corners(0).Y < 5) And (corners(2).X > newImage.Size.Width - 5 And corners(2).Y > newImage.Size.Height - 5) Then
                            ''nothing
                        Else
                            If (subType = PolygonSubType.Square) Or (subType = PolygonSubType.Rectangle) Then
                                ''If corners.Count = 4 Then

                                ''**************************************************************************************************************************
                                ''**************************************************************************************************************************

                                ''testColor = newImage.GetPixel(corners(0).X, corners(0).Y).Name

                                ''**************************************************************************************************************************
                                ''**************************************************************************************************************************

                                pen = greenPen
                                ''pen = whitePen
                                g.DrawPolygon(pen, ToPointsArray(corners))
                                Dim brush As New SolidBrush(Color.Green)
                                g.FillPolygon(brush, ToPointsArray(corners))

                                ''==============================================================================================
                                PictureBox1.Image = newImage

                                PictureBox1.Update()
                                ''System.Threading.Thread.Sleep(500)
                                ''==============================================================================================

                                ''Dim rc1 As PolygonSubType = PolygonSubType.Rectangle
                                ''rc1 = subType
                                ''k.DrawPolygon(Pens.Blue, ToPointsArray(corners))

                                ''Dim rc2 As Rectangle = New Rectangle(corners(0).X, corners(0).Y, corners(2).X - 1, corners(2).Y - 6)
                                ''k.DrawRectangle(Pens.Blue, ToPointsArray(corners))
                                ''k.DrawRectangle(Pens.Red, rc2)
                                ''PictureBox2.Image = newImage2
                                ''PictureBox2.Update()
                                ''System.Threading.Thread.Sleep(500)

                                ''Try
                                ''Dim p1 As System.Drawing.Point = New System.Drawing.Point(CInt(, h2 - CInt(y0))
                                ''Dim filter3 As New Crop(rc1)

                                ''cropped = filter3.Apply(newImage)

                                ''cropped = newImage.Clone(rc1, newImage.PixelFormat)
                                ''cropped.Save("cropped.Bmp", ImageFormat.Bmp)

                                ''PictureBox2.Image = cropped
                                ''PictureBox2.Update()
                                ''System.Threading.Thread.Sleep(500)


                                ''PictureBox1.Image = newImage

                                ''PictureBox1.Update()
                                ''System.Threading.Thread.Sleep(1000)


                                ''System.Threading.Thread.Sleep(1000)
                                ''miDoc = New MODI.Document
                                ''miDoc.Create("cropped.Bmp")

                                ''If miDoc.Images.Count <> 0 Then
                                ''AxMiDocView1.Document = miDoc
                                ''AxMiDocView1.Refresh()

                                ''AxMiDocView1.SelectAll(0)
                                ''AxMiDocView1.TextSelection.CopyToClipboard()

                                ''TextBox1.Paste()
                                ''PictureBox1.Image = cropped
                                ''PictureBox1.Update()
                                ''System.Threading.Thread.Sleep(500)

                                ''End If
                                ''j = j + 1
                                ''Dim modiImage As MODI.Image = DirectCast(miDoc.Images(0), MODI.Image)

                                ''modiImage.OCR(MODI.MiLANGUAGES.miLANG_ENGLISH, False, False) ''///////////////////////////////////////////////////////

                                ''AxMiDocView1.Document = miDoc
                                ''AxMiDocView1.Refresh()

                                ''For Each WordItem As MODI.Word In modiImage.Layout.Words

                                ''If WordItem.Text <> "" Then
                                ''str += WordItem.Text + " "
                                ''If WordItem.Text = "string" Or WordItem.Text = "String" Or WordItem.Text = "int" Or WordItem.Text = "int" Or WordItem.Text = "boolean" Or WordItem.Text = "Boolean" Or WordItem.Text = "void" Or WordItem.Text = "Void" Or WordItem.Text = "Integer" Or WordItem.Text = "integer" Or WordItem.Text = "bool" Or WordItem.Text = "Bool" Then str += Environment.NewLine
                                ''End If
                                ''  Next
                                ''Catch ex As Exception

                                ''miDoc.Close(False)
                                ''End Try


                                ''str += Environment.NewLine + "==============" + Environment.NewLine

                                ''TextBox3.Text += Environment.NewLine + str


                            End If
                        End If
                    End If

                End If



                i += 1
            End While

            ''TextBox3.Text += Environment.NewLine + str + "**************" + Environment.NewLine
            yellowPen.Dispose()
            redPen.Dispose()
            greenPen.Dispose()
            bluePen.Dispose()
            brownPen.Dispose()
            g.Dispose()


            ''*******************************************
            ''*******************************************
            For i = 0 To (newImage.Width - 1)
                For j = 0 To (newImage.Height - 1)
                    If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.Black)
                    ''If newImage.GetPixel(i, j).Name = "ff008000" Then newImage.SetPixel(i, j, Color.White)
                Next
            Next

            ''For i = 0 To (newImage.Width - 1)
            ''For j = 0 To (newImage.Height - 1)
            ''If newImage.GetPixel(i, j).Name <> "ff008000" Then newImage.SetPixel(i, j, Color.White)
            ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then newImage.SetPixel(i, j, Color.White)
            ''Next
            ''Next
            PictureBox2.Image = newImage
            PictureBox2.Update()

            Dim newimg As Bitmap = New Bitmap(newImage)
            ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
            ''newimg = filter.Apply(newimg)
            ''Dim filter1 As Filters.SobelEdgeDetector = New Filters.SobelEdgeDetector()
            ''newimg = filter1.Apply(newimg)

            ''Dim filter3 As New Dilatation()
            ''newimg = filter3.Apply(newimg)

            PictureBox2.Image = newimg
            PictureBox2.Update()

            doOCR(newimg, newImage2)
        Next
    End Sub

    Private Sub doOCR(ByVal newImage As Bitmap, ByVal newImage2 As Bitmap)

        ''Dim str As String = ""
        Dim miDoc1 As New MODI.Document
        ''Dim cropped As Bitmap
        ''AxMiDocView1.Document = miDoc
        ''AxMiDocView1.Refresh()
        Dim str As String = ""
        Dim cropped As Bitmap
        Dim blobCounter As BlobCounter = New BlobCounter(newImage)
        Dim rects As Rectangle() = blobCounter.GetObjectsRectangles()

        ''MsgBox("Number of rectangle is: " + rects.Count.ToString)


        For Each rc As Rectangle In rects
            cropped = newImage2.Clone(rc, newImage101.PixelFormat)

            ''Dim newImage3 As Bitmap = New Bitmap(PictureBox1.Image)

            cropped = ZoomImage(cropped, 400)

            cropped.Save("cropped.Bmp", ImageFormat.Bmp)
            Try
                ''Dim p1 As System.Drawing.Point = New System.Drawing.Point(CInt(, h2 - CInt(y0))
                ''Dim filter3 As New Crop(rc1)

                ''cropped = filter3.Apply(newImage)



                PictureBox2.Image = cropped
                PictureBox2.Update()
                ''System.Threading.Thread.Sleep(500)


                ''PictureBox1.Image = newImage

                ''PictureBox1.Update()
                ''System.Threading.Thread.Sleep(1000)


                ''System.Threading.Thread.Sleep(1000)
                ''AxMiDocView1.Document = Nothing
                If miDoc1 IsNot Nothing Then
                    miDoc1.Close()
                    miDoc1 = Nothing
                End If

                miDoc1 = New MODI.Document
                miDoc1.Create("cropped.Bmp")

                AxMiDocView1.Document = miDoc1
                AxMiDocView1.Refresh()


                ''****************************************************************************************************************************
                ''****************************************************************************************************************************
                ''****************************************************************************************************************************
                ''miDoc1.OCR(MiLANGUAGES.miLANG_ENGLISH, True, True)

                ''For l As Integer = 0 To miDoc1.Images.Count

                ''str += miDoc1.Images(l).Layout.Text
                ''Next

                ''miDoc1.Close()

                ''****************************************************************************************************************************
                ''****************************************************************************************************************************
                ''****************************************************************************************************************************

                ''If miDoc.Images.Count <> 0 Then
                ''AxMiDocView1.Document = miDoc
                ''AxMiDocView1.Refresh()

                ''AxMiDocView1.SelectAll(0)
                ''AxMiDocView1.TextSelection.CopyToClipboard()

                ''TextBox1.Paste()
                ''PictureBox1.Image = cropped
                ''PictureBox1.Update()
                ''System.Threading.Thread.Sleep(5000)

                ''End If
                ''j = j + 1

                ''****************************************************************************************************************************
                ''****************************************************************************************************************************
                ''****************************************************************************************************************************

                Dim modiImage As MODI.Image = DirectCast(miDoc1.Images(0), MODI.Image)

                modiImage.OCR(MODI.MiLANGUAGES.miLANG_ENGLISH, False, False) ''///////////////////////////////////////////////////////


                AxMiDocView1.Document = miDoc1
                AxMiDocView1.Refresh()

                ''System.Threading.Thread.Sleep(500)

                For Each WordItem As MODI.Word In modiImage.Layout.Words

                    If WordItem.Text <> "" Then
                        str += WordItem.Text + " "
                        ''If WordItem.Text = "string" Or WordItem.Text = "String" Or WordItem.Text = "int" Or WordItem.Text = "int" Or WordItem.Text = "boolean" Or WordItem.Text = "Boolean" Or WordItem.Text = "void" Or WordItem.Text = "Void" Or WordItem.Text = "Integer" Or WordItem.Text = "integer" Or WordItem.Text = "bool" Or WordItem.Text = "Bool" Then str += Environment.NewLine
                    End If
                Next
            Catch ex As Exception
                miDoc.Close(False)
            End Try


            ''str += Environment.NewLine + "==============" + Environment.NewLine

            ''TextBox3.Text += Environment.NewLine + str

            ''AxMiDocView1.Document = Nothing


            ''****************************************************************************************************************************
            ''****************************************************************************************************************************
            ''****************************************************************************************************************************

            ''AxMiDocView1.Document = miDoc1
            ''AxMiDocView1.Refresh()

            ''AxMiDocView1.SelectAll(0)


            ''str += AxMiDocView1.TextSelection.Text
            str += Environment.NewLine + "==============" + Environment.NewLine

            ''****************************************************************************************************************************
            ''****************************************************************************************************************************
            ''****************************************************************************************************************************

        Next
        TextBox3.Text += str + Environment.NewLine + "*****************" + Environment.NewLine

        ''****************************************************************************************************************************
        ''****************************************************************************************************************************
        ''****************************************************************************************************************************
    End Sub


    Private Sub Button7_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        TextBox1.Text = ""
        TextBox3.Text = ""

    End Sub


    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
        Dim mouseDownLocation As System.Drawing.Point = New System.Drawing.Point(e.X, e.Y)
        TextBox2.Text = "X: " + e.X.ToString + Environment.NewLine + "Y:" + e.Y.ToString

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)



        
        TextBox2.Text = TextBox2.Text + Environment.NewLine + newImage.GetPixel(e.X, e.Y).Name.ToString
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                ''TextBox1.Text = newImage.GetPixel(i, j).Name
                ''End If

            
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        For s = 0 To 5
            newImage = filter2.Apply(newImage)
        Next

        newImage = ZoomImage(newImage, 300)

        ''PictureBox1.Image = newImage

        ''PictureBox1.Update()

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)

        ''Dim filter3 As Filters.BrightnessCorrection = New Filters.BrightnessCorrection()
        ''newImage = filter3.Apply(newImage)

        ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As Filters.GaussianSharpen = New Filters.GaussianSharpen()
        ''newImage = filter.Apply(newImage)

        ''Dim filter1 As Filters.Sharpen = New Filters.Sharpen()
        ''For s = 0 To 4
        ''newImage = filter1.Apply(newImage)
        ''Next


        ''Dim filter2 As Filters.GaussianSharpen = New Filters.GaussianSharpen()
        ''For s = 0 To 5
        ''newImage = filter2.Apply(newImage)
        ''Next


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        ''Dim filter As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImg = filter.Apply(newImg)
        ''Dim filter1 As Filters.CannyEdgeDetector = New Filters.CannyEdgeDetector()
        ''Dim filter1 As Filters.Edges = New Filters.Edges()

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)
        Dim blobs As Blob() = blobCounter.GetObjectsInformation
        newImage.UnlockBits(bitmapData)

        Dim shapeChecker As SimpleShapeChecker = New SimpleShapeChecker()

        Dim g As Graphics = Graphics.FromImage(newImage)

        Dim yellowPen As Pen = New Pen(Color.Yellow, 2)       ' quadrilateral
        Dim redPen As Pen = New Pen(Color.Red, 4)       ' quadrilateral
        Dim brownPen As Pen = New Pen(Color.Brown, 4)   ' quadrilateral with known sub-type
        Dim greenPen As Pen = New Pen(Color.Green, 4)   ' known triangle
        Dim bluePen = New Pen(Color.Blue, 4)            ' triangle
        Dim whitePen = New Pen(Color.White, 4)

        Dim i As Integer = 0
        Dim n As Integer = blobs.Length
        While i < n


            Dim edgePoints As List(Of IntPoint) = blobCounter.GetBlobsEdgePoints(blobs(i))

            Dim center As DoublePoint
            Dim radius As Double

            'is Circle ??
            If shapeChecker.IsCircle(edgePoints, center, radius) Then
                g.DrawEllipse(yellowPen, CSng(center.X - radius), CSng(center.Y - radius), CSng(radius * 2), CSng(radius * 2))
            Else

                Dim corners As List(Of IntPoint)

                ' is triangle or quadrilateral
                If shapeChecker.IsConvexPolygon(edgePoints, corners) Then
                    'get sub-type
                    Dim subType As PolygonSubType = shapeChecker.CheckPolygonSubType(corners)
                    Dim pen As Pen


                    If (corners(0).X > 5 And corners(0).Y > 5) Or (corners(2).X < newImage.Size.Width - 5 And corners(2).Y < newImage.Size.Height - 5) Then
                        ''If (subType = PolygonSubType.Square) Or (subType = PolygonSubType.Rectangle) Then
                        ''If corners.Count = 4 Then

                        ''**************************************************************************************************************************
                        ''**************************************************************************************************************************

                        ''testColor = newImage.GetPixel(corners(0).X, corners(0).Y).Name

                        ''**************************************************************************************************************************
                        ''**************************************************************************************************************************
                        Dim brush As New SolidBrush(Color.Green)
                        ''If subType = PolygonSubType.Unknown Then
                        If corners.Count = 3 Then
                            brush.Color = Color.Red
                            pen = Pens.Red
                        Else
                            brush.Color = Color.Green
                            pen = Pens.Green
                        End If


                        ''pen = greenPen
                        ''pen = whitePen
                        g.DrawPolygon(pen, ToPointsArray(corners))
                        g.FillPolygon(brush, ToPointsArray(corners))

                        ''==============================================================================================
                        ''PictureBox1.Image = newImage

                        ''PictureBox1.Update()
                        ''==============================================================================================

                        ''Dim brush As New SolidBrush(Color.Green)
                        ''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                        ''Dim brush As New SolidBrush(Color.Brown)
                        ''If ((corners(0).X > 10) And (corners(0).Y > 10)) Then


                        ''==============================================================================================
                        ''PictureBox1.Image = newImage

                        ''PictureBox1.Update()
                        ''==============================================================================================

                        ''ElseIf ((corners(2).X < newImage.Width - 10) And (corners(2).Y < newImage.Height - 10)) Then
                        ''g.FillPolygon(brush, ToPointsArray(corners))

                        ''==============================================================================================
                        ''PictureBox1.Image = newImage

                        ''PictureBox1.Update()
                        ''==============================================================================================

                        ''End If
                        ''End If


                        ''########################################################################################################################################
                        ''########################################################################################################################################
                        ''Else
                        ''  If subType = PolygonSubType.Unknown Then
                        ''''If corners.Count = 4 Then
                        ''pen = bluePen
                        ''g.DrawPolygon(pen, ToPointsArray(corners))

                        ''Dim brush As New SolidBrush(Color.Blue)
                        ''''If ((corners(0).X <> 0) And (corners(0).Y <> 0) And (subType = PolygonSubType.Rectangle)) Then
                        ''''Dim brush As New SolidBrush(Color.Brown)
                        ''g.FillPolygon(brush, ToPointsArray(corners))

                        ''==============================================================================================
                        ''PictureBox1.Image = newImage

                        ''PictureBox1.Update()
                        ''==============================================================================================

                        ''End If

                        ''########################################################################################################################################
                        ''########################################################################################################################################

                        ''End If
                    End If

                End If
            End If



            i += 1
        End While

        yellowPen.Dispose()
        redPen.Dispose()
        greenPen.Dispose()
        bluePen.Dispose()
        brownPen.Dispose()
        g.Dispose()

        'put new image to clipboard
        ''Clipboard.SetDataObject(newImage)
        'and to picture box
        PictureBox1.Image = newImage

        ''PictureBox1.Update()
    End Sub

    Private Sub Button10_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Dim newImage2 As Bitmap = New Bitmap(PictureBox1.Image)
        Dim filter As Grayscale = New Grayscale(0.11, 0.59, 0.3)
        newImage2 = filter.Apply(newImage2)

        ''Dim filter8 As New Invert()
        ''newImage2 = filter8.Apply(newImage2)

        Dim hse As Short(,) = New Short(2, 2) {{-1, -1, -1},
                                               {1, 1, 0},
                                               {-1, -1, -1}}

        ''========Dim hFilter As New HitAndMiss(hse, HitAndMiss.Modes.HitAndMiss)
        ''========newImage2 = hFilter.Apply(newImage2)
        ''newImage2 = hFilter.Apply(newImage2)



        ''Dim vse As Short(,) = New Short(2, 2) {{-1, 1, -1}, {-1, 1, -1}, {-1, 1, -1}}

        ''Dim vFilter As New AForge.Imaging.Filters.HitAndMiss(vse, HitAndMiss.Modes.HitAndMiss)
        ''newImage2 = vFilter.Apply(newImage2)
        ''newImage2 = vFilter.Apply(newImage2)



        ''Dim filterSequence As New FiltersSequence()

        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, -1, -1}, {1, 1, 1}, {-1, -1, -1}}))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{1, -1, -1}, {1, -1, -1}, {1, -1, -1}}))  ''Vertical

        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, 0}, {-1, 1, -1}, {1, 1, 1}}, HitAndMiss.Modes.Thinning))  '' Horizantal
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 0, 0}, {1, 1, 0}, {-1, 1, -1}}, HitAndMiss.Modes.Thinning)) '' \\
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{1, -1, 0}, {1, 1, 0}, {1, -1, 0}}, HitAndMiss.Modes.Thinning))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 1, -1}, {1, 1, 0}, {-1, 0, 0}}, HitAndMiss.Modes.Thinning)) ''//
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{1, 1, 1}, {-1, 1, -1}, {0, 0, 0}}, HitAndMiss.Modes.Thinning))  ''Horizantal
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 1, -1}, {0, 1, 1}, {0, 0, -1}}, HitAndMiss.Modes.Thinning)) ''\\
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, -1, 1}, {0, 1, 1}, {0, -1, 1}}, HitAndMiss.Modes.Thinning))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, -1}, {0, 1, 1}, {-1, 1, -1}}, HitAndMiss.Modes.Thinning)) ''//

        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, 0}, {1, 1, 1}, {0, 0, 0}}, HitAndMiss.Modes.Thinning))
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}}, HitAndMiss.Modes.Thinning))

        ''Dim filter2 As New FilterIterator(filterSequence, 10)
        ''newImage2 = filter2.Apply(newImage2)
        ''========PictureBox1.Image = newImage2
        
        ''Dim hfilter As New AForge.Imaging.Filters.FilterIterator(New AForge.Imaging.Filters.HitAndMiss(New Short(,) {{1, 1, 1}, {-1, 0, -1}, {-1, -1, -1}}, HitAndMiss.Modes.Thinning), 5)
        ''newImage2 = hFilter.Apply(newImage2)

        ''PictureBox1.Image = newImage2

        ''Dim filter3 As Closing = New Closing()
        ''Dim filter3 As Opening = New Opening()
        Dim filter3 As Erosion = New Erosion()
        newImage2 = filter3.Apply(newImage2)
        PictureBox1.Image = newImage2

        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        newImage2 = filter2.Apply(newImage2)
        newImage2 = filter2.Apply(newImage2)

        Dim scd As SusanCornersDetector = New SusanCornersDetector()



        ''create corner maker filter
        ''Dim filter As CornersMarker = New CornersMarker(scd, Color.Red)
        ''apply the filter
        ''filter.ApplyInPlace(newImage)



        Dim corners As List(Of IntPoint) = scd.ProcessImage(newImage2)

        ''PictureBox1.Image = newImage2

        Dim newImage3 As Bitmap = New Bitmap(PictureBox1.Image)
        Dim graphics__1 As Graphics = Graphics.FromImage(newImage3)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)

        ''For Each corner As IntPoint In corners
        ''graphics__1.DrawRectangle(pen, corner.X - 1, corner.Y - 1, 3, 3)
        ''TextBox3.Text = TextBox3.Text + "+ corner X:" + corner.X.ToString + "    corner Y:" + corner.Y.ToString + Environment.NewLine
        ''Next

        ''######################################################################################
        ''######################################################################################

        ''PictureBox1.Image = newImage3

        ''Dim lenna As Bitmap = harris.Properties.Resources.lena512

        Dim numSigma = New System.Windows.Forms.NumericUpDown()
        Dim numThreshold = New System.Windows.Forms.NumericUpDown()
        Dim numK = New System.Windows.Forms.NumericUpDown()

        Dim sigma As Double = CDbl(numSigma.Value)
        Dim k As Single = CSng(numK.Value)
        Dim threshold As Single = CSng(numThreshold.Value)

        ' Create a new Harris Corners Detector using the given parameters
        Dim harris As New HarrisCornersDetector(k)
        ''harris.Measure = If(checkBox1.Checked, HarrisCornerMeasure.Harris, HarrisCornerMeasure.Nobel)
        harris.Threshold = threshold
        harris.Sigma = sigma

        ' Create a new AForge's Corner Marker Filter
        Dim corners1 As New CornersMarker(harris, Color.Green)

        ' Apply the filter and display it on a picturebox
        newImage3 = corners1.Apply(newImage3)
        PictureBox1.Image = newImage3

        PictureBox1.Update()


    End Sub

    Private Sub Button11_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click

        Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()

        Dim assembly As Assembly = Me.GetType().Assembly

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        ''For s = 0 To 5
        ''newImage = filter2.Apply(newImage)
        ''Next

        Dim sourceData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)
        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(sourceData)


        ''newImage = ZoomImage(newImage, 200)
        ''PictureBox1.Image = newImage

        Dim filter As New FiltersSequence(Grayscale.CommonAlgorithms.BT709, New Threshold(64))
        Dim lineTransform As New HoughLineTransformation()
        ''Dim sourceData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.[ReadOnly], newImage.PixelFormat)
        ' binarize the image
        Dim binarySource As UnmanagedImage = filter.Apply(New UnmanagedImage(sourceData))

        ' apply Hough line transofrm
        ''Dim filter2 As Filters.Grayscale = New Filters.Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter2.Apply(newImage)

        lineTransform.ProcessImage(binarySource)



        ' apply Hough line transofrm
        ''lineTransform.ProcessImage(newImage)
        Dim houghLineImage As Bitmap = lineTransform.ToBitmap()
        ' get lines using relative intensity
        Dim lines As HoughLine() = lineTransform.GetLinesByRelativeIntensity(0.2)

        For Each line As HoughLine In lines
            ' get line's radius and theta values
            Dim r As Integer = line.Radius
            Dim t As Double = line.Theta

            ' check if line is in lower part of the image
            If r < 0 Then
                t += 180
                r = -r
            End If

            ' convert degrees to radians
            t = (t / 180) * Math.PI

            ' get image centers (all coordinate are measured relative
            ' to center)
            Dim w2 As Integer = newImage.Width / 2
            Dim h2 As Integer = newImage.Height / 2

            Dim x0 As Double = 0, x1 As Double = 0, y0 As Double = 0, y1 As Double = 0

            If line.Theta <> 0 Then
                ' none-vertical line
                x0 = -w2
                ' most left point
                x1 = w2
                ' most right point
                ' calculate corresponding y values
                y0 = (-Math.Cos(t) * x0 + r) / Math.Sin(t)
                y1 = (-Math.Cos(t) * x1 + r) / Math.Sin(t)
            Else
                ' vertical line
                x0 = line.Radius
                x1 = line.Radius

                y0 = h2
                y1 = -h2
            End If

            ' draw line on the image
            Drawing.Line(sourceData, New IntPoint(CInt(x0) + w2, h2 - CInt(y0)), New IntPoint(CInt(x1) + w2, h2 - CInt(y1)), Color.Red)
        Next

        newImage.UnlockBits(sourceData)
        PictureBox1.Image = newImage

    End Sub

    Private Sub Button12_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)
        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)
        ''Dim filter1 As Filters.SobelEdgeDetector = New Filters.SobelEdgeDetector()
        ''newImg = filter1.Apply(newImg)
        Dim filterSequence As New FiltersSequence()

        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, -1, -1}, {1, -1, -1}, {1, -1, -1}}, HitAndMiss.Modes.Thinning))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{1, -1, -1}, {1, -1, -1}, {1, -1, -1}}, HitAndMiss.Modes.Thinning))  ''Vertical

        filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, 0}, {-1, 1, -1}, {1, 1, 1}}, HitAndMiss.Modes.Thinning))  '' Horizantal
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 0, 0}, {1, 1, 0}, {-1, 1, -1}}, HitAndMiss.Modes.Thinning)) '' \\
        filterSequence.Add(New HitAndMiss(New Short(,) {{1, -1, 0}, {1, 1, 0}, {1, -1, 0}}, HitAndMiss.Modes.Thinning))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 1, -1}, {1, 1, 0}, {-1, 0, 0}}, HitAndMiss.Modes.Thinning)) ''//
        filterSequence.Add(New HitAndMiss(New Short(,) {{1, 1, 1}, {-1, 1, -1}, {0, 0, 0}}, HitAndMiss.Modes.Thinning))  ''Horizantal
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{-1, 1, -1}, {0, 1, 1}, {0, 0, -1}}, HitAndMiss.Modes.Thinning)) ''\\
        filterSequence.Add(New HitAndMiss(New Short(,) {{0, -1, 1}, {0, 1, 1}, {0, -1, 1}}, HitAndMiss.Modes.Thinning))  ''Vertical
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, -1}, {0, 1, 1}, {-1, 1, -1}}, HitAndMiss.Modes.Thinning)) ''//

        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 0, 0}, {1, 1, 1}, {0, 0, 0}}, HitAndMiss.Modes.Thinning))
        ''filterSequence.Add(New HitAndMiss(New Short(,) {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}}, HitAndMiss.Modes.Thinning))
        Dim filter2 As New FilterIterator(filterSequence, 5)
        newImg = filter2.Apply(newImg)
        PictureBox1.Image = newImg


        ''PictureBox1.Update()
    End Sub

    Private Sub Button13_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Dim newImg As Bitmap = New Bitmap(PictureBox1.Image)

        Dim filter As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        newImg = filter.Apply(newImg)

        Dim se As Short(,) = New Short(,) {
        {1, -1, 1},
        {-1, -1, -1},
        {1, -1, 1}
        }
        '' create filter
        Dim filter4 As HitAndMiss = New HitAndMiss(se)
        ''For i = 1 To 2
        ''newImg = filter4.Apply(newImg)
        ''Next
        ''Dim filter1 As Filters.SobelEdgeDetector = New Filters.SobelEdgeDetector()
        ''newImg = filter1.Apply(newImg)
        ''Dim filter2 As New Dilatation(se)
        ''newImg = filter2.Apply(newImg)

        ''Dim filter3 As Erosion = New Erosion(se)

        ''apply the filter
        ''For i = 1 To 2
        ''newImg = filter3.Apply(newImg)
        ''Next
        PictureBox1.Image = newImg
        PictureBox1.Update()

        ''&&&&&&&&&&&&&&&&&&&&&&& Detect Corners  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

        TextBox3.Text = ""

        Dim image As New Bitmap(PictureBox1.Image)


        Dim graphics__1 As Graphics = Graphics.FromImage(image)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)

        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        ''For i = 0 To newImage.Width - 1
        ''For j = 0 To newImage.Height - 1
        ''If newImage.GetPixel(i, j).Name <> "ff000000" Then ''Then newImage.SetPixel(i, j, Color.White)
        ''''''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
        ''TextBox1.Text += newImage.GetPixel(i, j).Name + System.Environment.NewLine
        ''End If

        ''Next
        ''Next

        ''PictureBox1.Image = newImage
        ''PictureBox1.Update()
        ''System.Threading.Thread.Sleep(5000)

        ''Dim filter1 As AForge.Imaging.Filters.Grayscale = New AForge.Imaging.Filters.Grayscale(0.11, 0.59, 0.3)
        ''image = filter1.Apply(image)

        ''Dim filter2 As AForge.Imaging.Filters.GaussianSharpen = New AForge.Imaging.Filters.GaussianSharpen()
        ''For s = 0 To 2
        ''image = filter2.Apply(newImage)
        ''Next

        ''Dim filter3 As Erosion = New Erosion()
        ''image = filter3.Apply(image)

        ''Dim image2 As New Bitmap(image)

        Dim test As Boolean = True
        Dim Max_x, Max_y, Min_x, Min_y As Integer
        ' Create corner detector and have it process the image
        Dim mcd As New MoravecCornersDetector()
        Dim corners As List(Of IntPoint) = mcd.ProcessImage(newImage)
        ''Dim corners1 As List(Of IntPoint) = mcd.ProcessImage(image)

        ' Visualization: Draw 3x3 boxes around the corners
        For Each corner As IntPoint In corners
            graphics__1.DrawRectangle(pen, corner.X - 1, corner.Y - 1, 3, 3)
            For Each corner1 As IntPoint In corners
                test = True
                If corner <> corner1 Then
                    ''&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
                    If corner.X >= corner1.X + 5 Or corner.X <= corner1.X + 5 Then
                        Max_y = Math.Max(corner.Y, corner1.Y)
                        Min_y = Math.Min(corner.Y, corner1.Y)
                        If Max_y >= Min_y + 10 Then
                            ''temp = numOfPixel / 2
                            For j = Min_y To Max_y Step 2
                                ''If newImage.GetPixel(corner1.X, j).Name.ToString <> "fffdfdfd" Or newImage.GetPixel(corner1.X, j).Name.ToString <> "ffffffff" Then
                                If newImage.GetPixel(corner1.X, j).Name.ToString <> "ffffffff" Then
                                    ''TextBox3.Text = TextBox3.Text + Environment.NewLine + newImage.GetPixel(corner1.X, j).Name.ToString
                                    test = False
                                    Exit For
                                End If
                            Next
                            If test = False Then
                                Exit For
                            Else
                                graphics__1.DrawLine(pen1, corner.X, corner.Y, corner1.X, corner1.Y)
                                ''Exit For
                            End If
                        Else
                            Exit For
                        End If
                    End If
                    ''&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
                End If
                test = True
            Next
            ''TextBox3.Text = TextBox3.Text + "+ corner X:" + corner.X.ToString + "    corner Y:" + corner.Y.ToString + Environment.NewLine
        Next

        ' Display
        PictureBox1.Image = image
        PictureBox1.Update()



        ''&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    End Sub

    Private Sub Button14_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ffffffff" Then
                    For k = i + 1 To (newImage.Width - 1)
                        If newImage.GetPixel(k, j).Name <> "ffffffff" Then
                            If k > i + 20 Then
                                P1.X = i
                                P1.Y = j
                                p2.X = k - 1
                                p2.Y = j
                                graphics.DrawLine(pen1, P1, p2)
                                PictureBox1.Image = newImage
                                PictureBox1.Update()
                                Exit For
                            Else
                                Exit For
                            End If


                        End If

                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub Button15_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ffffffff" Then
                    For k = j + 1 To (newImage.Height - 1)
                        If newImage.GetPixel(i, k).Name <> "ffffffff" Then
                            If k > j + 20 Then
                                P1.X = i
                                P1.Y = j
                                p2.X = i
                                p2.Y = k - 1
                                graphics.DrawLine(pen1, P1, p2)
                                PictureBox1.Image = newImage
                                PictureBox1.Update()
                                Exit For
                            Else
                                Exit For
                            End If


                        End If

                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub Button18_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""

        ''Dim filter1 As Sharpen = New Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As GaussianSharpen = New GaussianSharpen()
        ''newImage = filter.Apply(newImage)
        ''Dim filter As Grayscale = New Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)
       

        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ffffffff" Then
                    Dim l As Integer = i
                    For k = j + 1 To (newImage.Height - 1)
                        If l <> 0 Then l = l - 1
                        If newImage.GetPixel(l, k).Name <> "ffffffff" Then
                            If k > j + 10 Then
                                P1.X = i
                                P1.Y = j
                                p2.X = l + 1
                                p2.Y = k - 1
                                graphics.DrawLine(pen1, p2, P1)
                                PictureBox1.Image = newImage
                                PictureBox1.Update()
                                Exit For
                            Else
                                Exit For
                            End If


                        End If
                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" And newImage.GetPixel(i, j).Name <> "ffffffff" And newImage.GetPixel(i, j).Name <> "ffff0000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub Button20_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""

        ''Dim filter1 As Sharpen = New Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As GaussianSharpen = New GaussianSharpen()
        ''newImage = filter.Apply(newImage)
        ''Dim filter As Grayscale = New Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                Dim m = 0, n = 0, o = 0
                If newImage.GetPixel(i, j).Name = "ffffff00" Then
                    Dim l As Integer
                    m = i
                    For k = j To (newImage.Height - 1)
                        If m < 10 Then m = 10
                        ''o = 0
                        For l = m - 5 To m + 5 ''becareful for (m+20) is bigger than newimage.width
                            If l = newImage.Width - 1 Then Exit For
                            If newImage.GetPixel(l, k).Name = "ffffff00" Then
                                newImage.SetPixel(l, k, Color.Yellow)
                                PictureBox1.Image = newImage
                                PictureBox1.Update()
                                m = l
                                n = k
                                o = 1
                                Exit For
                            End If
                        Next
                        If o = 0 Then
                            If m > i + 5 Or n > j + 10 Then
                                P1.X = i
                                P1.Y = j
                                p2.X = m
                                p2.Y = n
                                graphics.DrawLine(pen1, P1, p2)
                                PictureBox1.Image = newImage
                                PictureBox1.Update()
                                o = 0
                                Exit For
                            Else
                                ''o = 0
                                Exit For
                            End If
                        Else
                            o = 0
                            ''Exit For ''True if no white pixel down
                        End If

                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" And newImage.GetPixel(i, j).Name <> "ffffffff" And newImage.GetPixel(i, j).Name <> "ffff0000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button21_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""

        ''Dim filter1 As Sharpen = New Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As GaussianSharpen = New GaussianSharpen()
        ''newImage = filter.Apply(newImage)
        ''Dim filter As Grayscale = New Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.Red)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 4)

        For i = (newImage.Width - 1) To 0 Step -1
            For j = 0 To (newImage.Height - 1)
                Dim m = 0, n = 0, o = 0
                If newImage.GetPixel(i, j).Name = "ffffffff" Then
                    Dim l As Integer
                    m = i
                    For k = j + 1 To (newImage.Height - 1)
                        If m > (newImage.Width - 1) - 10 Then m = (newImage.Width - 1) - 10
                        ''o = 0
                        For l = m + 10 To m - 10 Step -1 ''becareful for (m+20) is bigger than newimage.width
                            If l <> i Then
                                If l <= 0 Then Exit For
                                If newImage.GetPixel(l, k).Name = "ffffffff" Then
                                    ''newImage.SetPixel(l, k, Color.Yellow)
                                    ''PictureBox1.Image = newImage
                                    ''PictureBox1.Update()
                                    m = l
                                    n = k
                                    o = 1
                                    ''Exit For
                                End If
                            End If
                        Next
                        If o = 0 Then
                            If ((m < i - 10) And (n > j + 3)) Or ((n > j + 10) And (m < i - 3)) Then
                                Dim y, slop, x, b As Double
                                slop = (n - j) / (m - i)
                                b = y - m * x
                                Dim tx1, tx2, ty1, ty2, tx3, ty3 As Integer
                                tx1 = (m + i) / 2
                                ty1 = (n + j) / 2
                                tx2 = (i + tx1) / 2
                                ty2 = (j + ty1) / 2
                                tx3 = (tx1 + m) / 2
                                ty3 = (ty1 + n) / 2

                                If ((newImage.GetPixel(tx1, ty1).Name = "ffffff00" Or newImage.GetPixel(tx1, ty1).Name = "ffffffff") And (newImage.GetPixel(tx2, ty2).Name = "ffffff00" Or newImage.GetPixel(tx2, ty2).Name = "ffffffff") And (newImage.GetPixel(tx3, ty3).Name = "ffffff00" Or newImage.GetPixel(tx3, ty3).Name = "ffffffff")) Then
                                    ''If (newImage.GetPixel(tx1, ty1).Name = "ffffffff" And newImage.GetPixel(tx2, ty2).Name = "ffffffff" And newImage.GetPixel(tx3, ty3).Name = "ffffffff") Then
                                    ''If (newImage.GetPixel(tx1, ty1).Name = "ffffff00" And newImage.GetPixel(tx2, ty2).Name = "ffffff00" And newImage.GetPixel(tx3, ty3).Name = "ffffff00") Then

                                    P1.X = i
                                    P1.Y = j
                                    p2.X = m
                                    p2.Y = n
                                    graphics.DrawLine(pen1, P1, p2)
                                    PictureBox1.Image = newImage
                                    PictureBox1.Update()
                                    ''o = 0
                                    Exit For
                                Else
                                    ''o = 0

                                    ''If (m = 359 And n = 836) Then MsgBox("newImage.GetPixel(m, n).Name =" + newImage.GetPixel(m, n).Name.ToString + Environment.NewLine +
                                    ''  "newImage.GetPixel(i, j).Name =" + newImage.GetPixel(i, j).Name.ToString + Environment.NewLine +
                                    ''"newImage.GetPixel(tx1, ty1).Name =" + newImage.GetPixel(tx1, ty1).Name.ToString + Environment.NewLine +
                                    ''"newImage.GetPixel(tx2, ty2).Name = " + newImage.GetPixel(tx2, ty2).Name.ToString + Environment.NewLine +
                                    ''"newImage.GetPixel(tx3, ty3).Name = " + newImage.GetPixel(tx3, ty3).Name.ToString)

                                    Exit For
                                End If
                            Else
                                ''o = 0
                                Exit For
                            End If
                        Else
                            o = 0
                            ''Exit For ''True if no white pixel
                        End If

                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" And newImage.GetPixel(i, j).Name <> "ffffffff" And newImage.GetPixel(i, j).Name <> "ffff0000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub Button22_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        Dim newImage As Bitmap = New Bitmap(newImage102)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""

        ''Dim filter1 As Sharpen = New Sharpen()
        ''newImage = filter1.Apply(newImage)

        ''Dim filter As GaussianSharpen = New GaussianSharpen()
        ''newImage = filter.Apply(newImage)
        ''Dim filter As Grayscale = New Grayscale(0.11, 0.59, 0.3)
        ''newImage = filter.Apply(newImage)


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim newImage1 As Bitmap = New Bitmap(PictureBox1.Image)
        Dim graphics As Graphics = graphics.FromImage(newImage1)
        Dim brush As New SolidBrush(Color.Green)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 4)

        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                Dim m = 0, n = 0, o = 0
                If newImage.GetPixel(i, j).Name = "ffffffff" Then
                    Dim l As Integer
                    m = i
                    For k = j + 1 To (newImage.Height - 1)
                        If m < 10 Then m = m + 10
                        ''o = 0
                        For l = m - 10 To m + 10 ''becareful for (m+20) is bigger than newimage.width
                            If l <> i Then
                                If l >= (newImage.Width - 1) Then Exit For
                                If newImage.GetPixel(l, k).Name = "ffffffff" Then
                                    ''newImage.SetPixel(l, k, Color.Yellow)
                                    ''PictureBox1.Image = newImage
                                    ''PictureBox1.Update()
                                    m = l
                                    n = k
                                    o = 1
                                    ''Exit For
                                End If
                            End If
                        Next
                        If o = 0 Then
                            If ((m > i + 10) And (n > j + 3)) Or ((n > j + 10) And (m > i + 3)) Then
                                Dim y, slop, x, b As Double
                                slop = (n - j) / (m - i)
                                b = y - m * x
                                Dim tx1, tx2, ty1, ty2, tx3, ty3 As Integer
                                tx1 = (m + i) / 2
                                ty1 = (n + j) / 2
                                tx2 = (i + tx1) / 2
                                ty2 = (j + ty1) / 2
                                tx3 = (tx1 + m) / 2
                                ty3 = (ty1 + n) / 2

                                If ((newImage.GetPixel(tx1, ty1).Name = "ffffff00" Or newImage.GetPixel(tx1, ty1).Name = "ffffffff") And (newImage.GetPixel(tx2, ty2).Name = "ffffff00" Or newImage.GetPixel(tx2, ty2).Name = "ffffffff") And (newImage.GetPixel(tx3, ty3).Name = "ffffff00" Or newImage.GetPixel(tx3, ty3).Name = "ffffffff")) Then
                                    ''If (newImage.GetPixel(tx1, ty1).Name = "ffffffff" And newImage.GetPixel(tx2, ty2).Name = "ffffffff" And newImage.GetPixel(tx3, ty3).Name = "ffffffff") Then
                                    ''If (newImage.GetPixel(tx1, ty1).Name = "ffffff00" And newImage.GetPixel(tx2, ty2).Name = "ffffff00" And newImage.GetPixel(tx3, ty3).Name = "ffffff00") Then

                                    P1.X = i
                                    P1.Y = j
                                    p2.X = m
                                    p2.Y = n
                                    graphics.DrawLine(pen1, P1, p2)
                                    PictureBox1.Image = newImage1
                                    PictureBox1.Update()
                                    ''o = 0
                                    Exit For
                                Else
                                    ''o = 0
                                    Exit For
                                End If
                            Else
                                ''o = 0
                                Exit For
                            End If
                        Else
                            o = 0
                            ''Exit For ''True if no white pixel
                        End If

                    Next

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" And newImage.GetPixel(i, j).Name <> "ffffffff" And newImage.GetPixel(i, j).Name <> "ffff0000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage1
    End Sub

    Private Sub Button23_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.HotPink)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)
        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ffffffff" Then

                    ''##################################################################################################################
                    Dim k = i + 1, l = 0, m = 0
                    If k < newImage.Width Then
                        Do Until k = (newImage.Width - 1)
                            ''For k = i + 1 To (newImage.Width - 1)
                            If newImage.GetPixel(k, j).Name <> "ffffffff" Then
                                If k + l >= (newImage.Width - 1) Then Exit Do
                                k = k + l
                                ''l = 0
                                m = m + 1 '' number of dashes
                                If newImage.GetPixel(k, j).Name <> "ffffffff" Then
                                    If m > 1 Then
                                        P1.X = i
                                        P1.Y = j
                                        p2.X = k - l / 2
                                        p2.Y = j
                                        graphics.DrawLine(pen1, P1, p2)
                                        PictureBox1.Image = newImage
                                        PictureBox1.Update()
                                        Exit Do
                                    Else
                                        Exit Do
                                    End If

                                Else
                                    ''Exit Do
                                    ''l = l + 1
                                    k = k + 1
                                End If
                            Else
                                l = l + 1
                                k = k + 1
                            End If
                            ''Next
                        Loop
                    End If
                    ''##################################################################################################################

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub

    Private Sub Button24_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        Dim newImage As Bitmap = New Bitmap(PictureBox1.Image)
        Dim P1, p2, P3 As New System.Drawing.Point

        TextBox3.Text = ""


        Dim bitmapData As BitmapData = newImage.LockBits(New Rectangle(0, 0, newImage.Width, newImage.Height), ImageLockMode.ReadWrite, newImage.PixelFormat)

        Dim colorFilter As ColorFiltering = New ColorFiltering

        colorFilter.Red = New IntRange(0, 64)
        colorFilter.Green = New IntRange(0, 64)
        colorFilter.Blue = New IntRange(0, 64)
        colorFilter.FillOutsideRange = False

        colorFilter.ApplyInPlace(bitmapData)

        Dim blobCounter As BlobCounter = New BlobCounter()

        blobCounter.FilterBlobs = True
        blobCounter.MinHeight = 5
        blobCounter.MinWidth = 5

        blobCounter.ProcessImage(bitmapData)



        newImage.UnlockBits(bitmapData)

        Dim str As String = ""
        Dim graphics As Graphics = graphics.FromImage(newImage)
        Dim brush As New SolidBrush(Color.HotPink)
        Dim pen As New Pen(brush)
        Dim pen1 As New Pen(brush, 3)
        For i = 0 To (newImage.Width - 1)
            For j = 0 To (newImage.Height - 1)
                If newImage.GetPixel(i, j).Name = "ffffffff" Then

                    ''##################################################################################################################
                    Dim k = i + 1, l = 0, m = 0
                    If k < newImage.Width Then
                        Do Until k = (newImage.Width - 1)
                            ''For k = i + 1 To (newImage.Width - 1)
                            If newImage.GetPixel(k, j).Name <> "ffffffff" Then
                                If k + l >= (newImage.Width - 1) Then Exit Do
                                k = k + l
                                ''l = 0
                                m = m + 1 '' number of dashes
                                If newImage.GetPixel(k, j).Name <> "ffffffff" Then
                                    If m > 1 Then
                                        P1.X = i
                                        P1.Y = j
                                        p2.X = k - l / 2
                                        p2.Y = j
                                        graphics.DrawLine(pen1, P1, p2)
                                        PictureBox1.Image = newImage
                                        PictureBox1.Update()
                                        Exit Do
                                    Else
                                        Exit Do
                                    End If

                                Else
                                    ''Exit Do
                                    ''l = l + 1
                                    k = k + 1
                                End If
                            Else
                                l = l + 1
                                k = k + 1
                            End If
                            ''Next
                        Loop
                    End If
                    ''##################################################################################################################

                End If
                ''If newImage.GetPixel(i, j).Name = "ffffffff" Then newImage.SetPixel(i, j, Color.Red)
                ''If newImage.GetPixel(i, j).Name <> "ffffffff" Then
                If newImage.GetPixel(i, j).Name <> "ff000000" Then
                    str = str + Environment.NewLine + newImage.GetPixel(i, j).Name.ToString
                    ''Exit For
                End If


            Next
        Next
        TextBox3.Text = str
        PictureBox1.Image = newImage
    End Sub
End Class
